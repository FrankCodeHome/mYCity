import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Image } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { format } from 'date-fns';

const RESERVATIONS = [
  {
    id: '1',
    restaurant: 'Le Bernardin',
    image: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4',
    date: new Date(2025, 2, 15, 19, 30),
    guests: 2,
    status: 'upcoming',
  },
  {
    id: '2',
    restaurant: 'Nobu Downtown',
    image: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5',
    date: new Date(2025, 2, 10, 20, 0),
    guests: 4,
    status: 'completed',
  },
];

export default function ReservationsScreen() {
  const upcomingReservations = RESERVATIONS.filter((r) => r.status === 'upcoming');
  const pastReservations = RESERVATIONS.filter((r) => r.status === 'completed');

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Your Reservations</Text>
      </View>

      <ScrollView>
        {upcomingReservations.length > 0 && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Upcoming</Text>
            {upcomingReservations.map((reservation) => (
              <TouchableOpacity key={reservation.id} style={styles.reservationCard}>
                <Image
                  source={{ uri: `${reservation.image}?w=200&q=80` }}
                  style={styles.restaurantImage}
                />
                <View style={styles.reservationInfo}>
                  <Text style={styles.restaurantName}>{reservation.restaurant}</Text>
                  <Text style={styles.reservationDetails}>
                    {format(reservation.date, 'MMM d, yyyy')} at{' '}
                    {format(reservation.date, 'h:mm a')}
                  </Text>
                  <Text style={styles.guestCount}>
                    {reservation.guests} {reservation.guests === 1 ? 'guest' : 'guests'}
                  </Text>
                  <TouchableOpacity style={styles.modifyButton}>
                    <Text style={styles.modifyButtonText}>Modify</Text>
                  </TouchableOpacity>
                </View>
              </TouchableOpacity>
            ))}
          </View>
        )}

        {pastReservations.length > 0 && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Past Reservations</Text>
            {pastReservations.map((reservation) => (
              <TouchableOpacity key={reservation.id} style={styles.reservationCard}>
                <Image
                  source={{ uri: `${reservation.image}?w=200&q=80` }}
                  style={styles.restaurantImage}
                />
                <View style={styles.reservationInfo}>
                  <Text style={styles.restaurantName}>{reservation.restaurant}</Text>
                  <Text style={styles.reservationDetails}>
                    {format(reservation.date, 'MMM d, yyyy')} at{' '}
                    {format(reservation.date, 'h:mm a')}
                  </Text>
                  <Text style={styles.guestCount}>
                    {reservation.guests} {reservation.guests === 1 ? 'guest' : 'guests'}
                  </Text>
                  <TouchableOpacity style={styles.rateButton}>
                    <Text style={styles.rateButtonText}>Rate your experience</Text>
                  </TouchableOpacity>
                </View>
              </TouchableOpacity>
            ))}
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  header: {
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#E8E8E8',
  },
  title: {
    fontSize: 28,
    fontWeight: '700',
    color: '#2D2D2D',
  },
  section: {
    padding: 16,
  },
  sectionTitle: {
    fontSize: 22,
    fontWeight: '600',
    marginBottom: 16,
    color: '#2D2D2D',
  },
  reservationCard: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    borderRadius: 12,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  restaurantImage: {
    width: 100,
    height: 100,
    borderTopLeftRadius: 12,
    borderBottomLeftRadius: 12,
  },
  reservationInfo: {
    flex: 1,
    padding: 12,
  },
  restaurantName: {
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 4,
    color: '#2D2D2D',
  },
  reservationDetails: {
    fontSize: 14,
    color: '#6B6B6B',
    marginBottom: 4,
  },
  guestCount: {
    fontSize: 14,
    color: '#6B6B6B',
    marginBottom: 8,
  },
  modifyButton: {
    backgroundColor: '#DA3743',
    padding: 8,
    borderRadius: 6,
    alignSelf: 'flex-start',
  },
  modifyButtonText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: '600',
  },
  rateButton: {
    backgroundColor: '#F5F5F5',
    padding: 8,
    borderRadius: 6,
    alignSelf: 'flex-start',
  },
  rateButtonText: {
    color: '#2D2D2D',
    fontSize: 14,
    fontWeight: '600',
  },
});