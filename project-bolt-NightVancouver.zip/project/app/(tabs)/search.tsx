import { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TextInput, TouchableOpacity, Image } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Search, Filter } from 'lucide-react-native';

const CUISINES = ['American', 'Italian', 'Japanese', 'French', 'Chinese', 'Mexican', 'Indian', 'Thai'];

export default function SearchScreen() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCuisine, setSelectedCuisine] = useState<string | null>(null);

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <View style={styles.searchContainer}>
          <Search size={20} color="#6B6B6B" style={styles.searchIcon} />
          <TextInput
            style={styles.searchInput}
            placeholder="Search restaurants, cuisines, or areas"
            placeholderTextColor="#6B6B6B"
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
        </View>
        <TouchableOpacity style={styles.filterButton}>
          <Filter size={20} color="#DA3743" />
        </TouchableOpacity>
      </View>

      <ScrollView>
        <View style={styles.cuisinesContainer}>
          <Text style={styles.sectionTitle}>Popular Cuisines</Text>
          <View style={styles.cuisineGrid}>
            {CUISINES.map((cuisine) => (
              <TouchableOpacity
                key={cuisine}
                style={[
                  styles.cuisineButton,
                  selectedCuisine === cuisine && styles.selectedCuisine,
                ]}
                onPress={() => setSelectedCuisine(cuisine)}>
                <Text
                  style={[
                    styles.cuisineText,
                    selectedCuisine === cuisine && styles.selectedCuisineText,
                  ]}>
                  {cuisine}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Popular Searches</Text>
          {['Outdoor Seating', 'Date Night', 'Family Style', 'Business Lunch'].map((item) => (
            <TouchableOpacity key={item} style={styles.searchItem}>
              <Text style={styles.searchItemText}>{item}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  header: {
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    borderBottomWidth: 1,
    borderBottomColor: '#E8E8E8',
  },
  searchContainer: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F5F5F5',
    borderRadius: 8,
    padding: 12,
    marginRight: 12,
  },
  searchIcon: {
    marginRight: 8,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    color: '#2D2D2D',
  },
  filterButton: {
    padding: 12,
    backgroundColor: '#F5F5F5',
    borderRadius: 8,
  },
  section: {
    padding: 16,
  },
  sectionTitle: {
    fontSize: 22,
    fontWeight: '700',
    marginBottom: 16,
    color: '#2D2D2D',
  },
  cuisinesContainer: {
    padding: 16,
  },
  cuisineGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginHorizontal: -8,
  },
  cuisineButton: {
    width: '25%',
    padding: 8,
  },
  selectedCuisine: {
    backgroundColor: '#DA3743',
    borderRadius: 8,
  },
  cuisineText: {
    textAlign: 'center',
    fontSize: 14,
    color: '#2D2D2D',
    padding: 8,
  },
  selectedCuisineText: {
    color: '#fff',
  },
  searchItem: {
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#E8E8E8',
  },
  searchItemText: {
    fontSize: 16,
    color: '#2D2D2D',
  },
});