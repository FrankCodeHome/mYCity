import { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Image, TouchableOpacity, TextInput } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Search, MapPin, BookOpen, UtensilsCrossed, Beer, Tv, Music } from 'lucide-react-native';
import { Link } from 'expo-router';

const CATEGORIES = [
  { icon: BookOpen, label: 'Study' },
  { icon: UtensilsCrossed, label: 'Dining' },
  { icon: Beer, label: 'Bar' },
  { icon: Tv, label: 'Watch Football' },
  { icon: Music, label: 'Entertainment' },
];

const SPONSORS = [
  {
    id: '1',
    name: 'Vancouver Canucks',
    logo: 'https://images.unsplash.com/photo-1515002246390-7bf7e8f87b54',
    description: 'Official sports bar partner',
    fullDescription: 'Experience the thrill of Canucks games at our partner sports bars across Vancouver. Exclusive game-day specials and premium viewing experiences.',
    website: 'www.canucks.com',
    locations: ['Rogers Arena', 'Downtown Vancouver'],
    partnerships: ['The Score Sports Bar', 'Stadium Pub', 'Hockey Haven'],
  },
  {
    id: '2',
    name: 'Granville Entertainment',
    logo: 'https://images.unsplash.com/photo-1516450360452-9312f5e86fc7',
    description: 'Premium nightlife venues',
    fullDescription: "Your gateway to Vancouver's most exclusive nightlife experiences. Multiple venues offering unique atmospheres and world-class entertainment.",
    website: 'www.granvilleent.com',
    venues: ['Club Vogue', 'The Roxy', 'Studio 54'],
    events: ['Live Music Thursdays', 'DJ Nights', 'Comedy Shows'],
  },
  {
    id: '3',
    name: 'Study Spaces Vancouver',
    logo: 'https://images.unsplash.com/photo-1497633762265-9d179a990aa6',
    description: 'Quiet study locations',
    fullDescription: 'Network of premium study spaces across Vancouver. Offering quiet environments, high-speed internet, and unlimited premium coffee.',
    website: 'www.studyspaces.ca',
    amenities: ['Free Wi-Fi', '24/7 Access', 'Meeting Rooms'],
    locations: ['Downtown', 'UBC Area', 'Kitsilano'],
  },
];

const FEATURED_VENUES = [
  {
    id: '1',
    name: 'The Study Café',
    image: 'https://images.unsplash.com/photo-1554118811-1e0d58224f24',
    cuisine: 'Café',
    price: '$$',
    rating: 4.8,
    location: 'Downtown Vancouver',
  },
  {
    id: '2',
    name: 'The Score Sports Bar',
    image: 'https://images.unsplash.com/photo-1566633806327-68e152aaf26d',
    cuisine: 'Sports Bar',
    price: '$$',
    rating: 4.7,
    location: 'Granville',
  },
  {
    id: '3',
    name: 'Nightlife Lounge',
    image: 'https://images.unsplash.com/photo-1566417713940-fe7c737a9ef2',
    cuisine: 'Bar & Entertainment',
    price: '$$$',
    rating: 4.6,
    location: 'Yaletown',
  },
  {
    id: '4',
    name: 'Library Café',
    image: 'https://images.unsplash.com/photo-1559925393-8be0ec4767c8',
    cuisine: 'Study Café',
    price: '$',
    rating: 4.9,
    location: 'UBC Area',
  },
  {
    id: '5',
    name: 'The Pitch & Pint',
    image: 'https://images.unsplash.com/photo-1574096079513-d8259312b785',
    cuisine: 'Sports Bar',
    price: '$$',
    rating: 4.5,
    location: 'Gastown',
  },
  {
    id: '6',
    name: 'Study Hub',
    image: 'https://images.unsplash.com/photo-1497633762265-9d179a990aa6',
    cuisine: 'Study Space',
    price: '$',
    rating: 4.8,
    location: 'Kitsilano',
  },
  {
    id: '7',
    name: 'Club Nova',
    image: 'https://images.unsplash.com/photo-1566737236500-c8ac43014a67',
    cuisine: 'Nightclub',
    price: '$$$',
    rating: 4.7,
    location: 'Downtown',
  },
  {
    id: '8',
    name: 'Cram Corner',
    image: 'https://images.unsplash.com/photo-1497032628192-86f99bcd76bc',
    cuisine: 'Study Café',
    price: '$',
    rating: 4.6,
    location: 'Commercial Drive',
  },
  {
    id: '9',
    name: 'Sports Central',
    image: 'https://images.unsplash.com/photo-1567337710282-00832b415979',
    cuisine: 'Sports Bar',
    price: '$$',
    rating: 4.5,
    location: 'Downtown',
  },
];

const ADS = [
  {
    id: '1',
    image: 'https://images.unsplash.com/photo-1517457373958-b7bdd4587205',
    title: 'Student Study Package',
    description: 'Unlimited coffee with 4-hour study room booking',
    fullDescription: 'Get the most out of your study sessions with our exclusive student package. Includes unlimited premium coffee, dedicated study room for 4 hours, high-speed Wi-Fi, and power outlets at every seat.',
    price: '$25/person',
    validity: 'Valid Monday to Friday',
    locations: ['Downtown', 'UBC Area', 'Kitsilano'],
    terms: ['Student ID required', 'Subject to availability', 'Prior booking recommended'],
  },
  {
    id: '2',
    image: 'https://images.unsplash.com/photo-1545128485-c400e7702796',
    title: 'Game Night Special',
    description: 'Wings & Beer combo during live games',
    fullDescription: 'The ultimate sports viewing experience! Watch your favorite teams on our giant screens while enjoying our famous wings and craft beer selection.',
    price: '$30/person',
    includes: ['1 pound of wings', '2 pints of draft beer', 'Reserved seating'],
    validity: 'Valid during live games',
    locations: ['All sports bar locations'],
  },
  {
    id: '3',
    image: 'https://images.unsplash.com/photo-1470337458703-46ad1756a187',
    title: 'Live Music Tonight',
    description: 'Local bands at top venues',
    fullDescription: "Experience Vancouver's vibrant music scene with live performances by top local bands. Different genres every night!",
    price: '$15 cover',
    schedule: 'Thursday to Saturday, 8 PM onwards',
    venues: ['The Roxy', 'Club Vogue', 'Studio 54'],
    features: ['Live bands', 'Dance floor', 'Drink specials'],
  },
];

export default function HomeScreen() {
  const [location, setLocation] = useState('Vancouver, BC');
  const [activeAdIndex, setActiveAdIndex] = useState(0);

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView>
        <View style={styles.header}>
          <View style={styles.locationContainer}>
            <MapPin size={20} color="#DA3743" />
            <Text style={styles.location}>{location}</Text>
          </View>
          
          <View style={styles.searchContainer}>
            <Search size={20} color="#6B6B6B" style={styles.searchIcon} />
            <TextInput
              style={styles.searchInput}
              placeholder="Search venues, areas, or categories"
              placeholderTextColor="#6B6B6B"
            />
          </View>
        </View>

        <View style={styles.categoriesContainer}>
          <ScrollView 
            horizontal 
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.categoriesContent}>
            {CATEGORIES.map((category, index) => (
              <TouchableOpacity key={index} style={styles.categoryButton}>
                <View style={styles.categoryIcon}>
                  <category.icon size={24} color="#DA3743" />
                </View>
                <Text style={styles.categoryLabel}>{category.label}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Sponsorship Partners</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false}>
            {SPONSORS.map((sponsor) => (
              <Link
                key={sponsor.id}
                href={`/sponsor/${sponsor.id}`}
                asChild>
                <TouchableOpacity style={styles.sponsorCard}>
                  <Image source={{ uri: `${sponsor.logo}?w=200&q=80` }} style={styles.sponsorLogo} />
                  <View style={styles.sponsorInfo}>
                    <Text style={styles.sponsorName}>{sponsor.name}</Text>
                    <Text style={styles.sponsorDescription}>{sponsor.description}</Text>
                  </View>
                </TouchableOpacity>
              </Link>
            ))}
          </ScrollView>
        </View>

        <View style={styles.adsContainer}>
          <ScrollView
            horizontal
            pagingEnabled
            showsHorizontalScrollIndicator={false}
            onMomentumScrollEnd={(event) => {
              const newIndex = Math.round(
                event.nativeEvent.contentOffset.x / event.nativeEvent.layoutMeasurement.width
              );
              setActiveAdIndex(newIndex);
            }}>
            {ADS.map((ad) => (
              <Link
                key={ad.id}
                href={`/ad/${ad.id}`}
                asChild>
                <TouchableOpacity style={styles.adCard}>
                  <Image source={{ uri: `${ad.image}?w=800&q=80` }} style={styles.adImage} />
                  <View style={styles.adOverlay}>
                    <Text style={styles.adTitle}>{ad.title}</Text>
                    <Text style={styles.adDescription}>{ad.description}</Text>
                  </View>
                </TouchableOpacity>
              </Link>
            ))}
          </ScrollView>
          <View style={styles.paginationDots}>
            {ADS.map((_, index) => (
              <View
                key={index}
                style={[
                  styles.paginationDot,
                  index === activeAdIndex && styles.paginationDotActive,
                ]}
              />
            ))}
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Featured Venues</Text>
          <View style={styles.venueGrid}>
            {FEATURED_VENUES.map((venue) => (
              <Link
                key={venue.id}
                href={`/venue/${venue.id}`}
                asChild>
                <TouchableOpacity style={styles.venueCard}>
                  <Image
                    source={{ uri: `${venue.image}?w=400&q=80` }}
                    style={styles.venueImage}
                  />
                  <View style={styles.venueInfo}>
                    <Text style={styles.venueName}>{venue.name}</Text>
                    <Text style={styles.venueDetails}>
                      {venue.cuisine} • {venue.price}
                    </Text>
                    <View style={styles.ratingContainer}>
                      <Text style={styles.rating}>★ {venue.rating}</Text>
                      <Text style={styles.location}>{venue.location}</Text>
                    </View>
                  </View>
                </TouchableOpacity>
              </Link>
            ))}
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  header: {
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#E8E8E8',
  },
  locationContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  location: {
    fontSize: 16,
    fontWeight: '600',
    marginLeft: 8,
    color: '#2D2D2D',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F5F5F5',
    borderRadius: 8,
    padding: 12,
  },
  searchIcon: {
    marginRight: 8,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    color: '#2D2D2D',
  },
  section: {
    padding: 16,
  },
  sectionTitle: {
    fontSize: 22,
    fontWeight: '700',
    marginBottom: 16,
    color: '#2D2D2D',
  },
  categoriesContainer: {
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#E8E8E8',
  },
  categoriesContent: {
    paddingHorizontal: 16,
  },
  categoryButton: {
    alignItems: 'center',
    marginRight: 24,
  },
  categoryIcon: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: '#FFF0F1',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 8,
  },
  categoryLabel: {
    fontSize: 12,
    color: '#2D2D2D',
    fontWeight: '500',
  },
  sponsorCard: {
    width: 280,
    marginRight: 16,
    backgroundColor: '#fff',
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  sponsorLogo: {
    width: '100%',
    height: 120,
    borderTopLeftRadius: 12,
    borderTopRightRadius: 12,
  },
  sponsorInfo: {
    padding: 12,
  },
  sponsorName: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 4,
    color: '#2D2D2D',
  },
  sponsorDescription: {
    fontSize: 14,
    color: '#6B6B6B',
  },
  adsContainer: {
    height: 200,
    marginBottom: 16,
  },
  adCard: {
    width: 400,
    height: 180,
    position: 'relative',
  },
  adImage: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
  },
  adOverlay: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    padding: 16,
    backgroundColor: 'rgba(0,0,0,0.5)',
  },
  adTitle: {
    color: '#fff',
    fontSize: 20,
    fontWeight: '600',
    marginBottom: 4,
  },
  adDescription: {
    color: '#fff',
    fontSize: 14,
  },
  paginationDots: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    position: 'absolute',
    bottom: 8,
    left: 0,
    right: 0,
  },
  paginationDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: 'rgba(255,255,255,0.5)',
    marginHorizontal: 4,
  },
  paginationDotActive: {
    backgroundColor: '#fff',
  },
  venueGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginHorizontal: -8,
  },
  venueCard: {
    width: '48%',
    marginHorizontal: '1%',
    marginBottom: 16,
    backgroundColor: '#fff',
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  venueImage: {
    width: '100%',
    height: 150,
    borderTopLeftRadius: 12,
    borderTopRightRadius: 12,
  },
  venueInfo: {
    padding: 12,
  },
  venueName: {
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 4,
    color: '#2D2D2D',
  },
  venueDetails: {
    fontSize: 14,
    color: '#6B6B6B',
    marginBottom: 4,
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  rating: {
    fontSize: 14,
    fontWeight: '600',
    color: '#DA3743',
    marginRight: 8,
  },
});

export { SPONSORS };
export { ADS };