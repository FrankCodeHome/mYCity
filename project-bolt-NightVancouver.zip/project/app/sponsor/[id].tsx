import { View, Text, StyleSheet, ScrollView, Image, TouchableOpacity, Platform } from 'react-native';
import { useLocalSearchParams, router } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { ChevronLeft, Globe, MapPin, Share2 } from 'lucide-react-native';

// Import SPONSORS data from the home screen
import { SPONSORS } from '../(tabs)/index';

export default function SponsorDetails() {
  const { id } = useLocalSearchParams();
  const sponsor = SPONSORS.find(s => s.id === id);

  if (!sponsor) {
    return (
      <View style={styles.container}>
        <Text>Sponsor not found</Text>
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView>
        <View style={styles.header}>
          <TouchableOpacity
            style={styles.backButton}
            onPress={() => router.back()}>
            <ChevronLeft size={24} color="#fff" />
          </TouchableOpacity>
          <TouchableOpacity style={styles.shareButton}>
            <Share2 size={24} color="#fff" />
          </TouchableOpacity>
        </View>

        <Image
          source={{ uri: `${sponsor.logo}?w=800&q=80` }}
          style={styles.coverImage}
        />

        <View style={styles.content}>
          <Text style={styles.name}>{sponsor.name}</Text>
          <Text style={styles.description}>{sponsor.fullDescription}</Text>

          <View style={styles.infoContainer}>
            <View style={styles.infoItem}>
              <Globe size={20} color="#6B6B6B" />
              <Text style={styles.infoText}>{sponsor.website}</Text>
            </View>
            
            {sponsor.locations && (
              <View style={styles.infoItem}>
                <MapPin size={20} color="#6B6B6B" />
                <Text style={styles.infoText}>{sponsor.locations.join(', ')}</Text>
              </View>
            )}
          </View>

          {sponsor.partnerships && (
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Partner Venues</Text>
              {sponsor.partnerships.map((partnership, index) => (
                <Text key={index} style={styles.listItem}>{partnership}</Text>
              ))}
            </View>
          )}

          {sponsor.venues && (
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Our Venues</Text>
              {sponsor.venues.map((venue, index) => (
                <Text key={index} style={styles.listItem}>{venue}</Text>
              ))}
            </View>
          )}

          {sponsor.events && (
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Featured Events</Text>
              {sponsor.events.map((event, index) => (
                <Text key={index} style={styles.listItem}>{event}</Text>
              ))}
            </View>
          )}

          {sponsor.amenities && (
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Amenities</Text>
              {sponsor.amenities.map((amenity, index) => (
                <Text key={index} style={styles.listItem}>{amenity}</Text>
              ))}
            </View>
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  header: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: Platform.OS === 'web' ? 16 : 0,
    paddingTop: Platform.OS === 'web' ? 16 : 48,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 16,
  },
  shareButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  coverImage: {
    width: '100%',
    height: 300,
  },
  content: {
    padding: 16,
  },
  name: {
    fontSize: 28,
    fontWeight: '700',
    color: '#2D2D2D',
    marginBottom: 8,
  },
  description: {
    fontSize: 16,
    color: '#2D2D2D',
    lineHeight: 24,
    marginBottom: 24,
  },
  infoContainer: {
    marginBottom: 24,
  },
  infoItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  infoText: {
    fontSize: 14,
    color: '#6B6B6B',
    marginLeft: 8,
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: '#2D2D2D',
    marginBottom: 12,
  },
  listItem: {
    fontSize: 16,
    color: '#2D2D2D',
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#E8E8E8',
  },
});