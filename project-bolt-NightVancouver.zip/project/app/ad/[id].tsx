import { View, Text, StyleSheet, ScrollView, Image, TouchableOpacity, Platform } from 'react-native';
import { useLocalSearchParams, router } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { ChevronLeft, Share2, MapPin, Clock, DollarSign } from 'lucide-react-native';

// Import ADS data from the home screen
import { ADS } from '../(tabs)/index';

export default function AdDetails() {
  const { id } = useLocalSearchParams();
  const ad = ADS.find(a => a.id === id);

  if (!ad) {
    return (
      <View style={styles.container}>
        <Text>Advertisement not found</Text>
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView>
        <View style={styles.header}>
          <TouchableOpacity
            style={styles.backButton}
            onPress={() => router.back()}>
            <ChevronLeft size={24} color="#fff" />
          </TouchableOpacity>
          <TouchableOpacity style={styles.shareButton}>
            <Share2 size={24} color="#fff" />
          </TouchableOpacity>
        </View>

        <Image
          source={{ uri: `${ad.image}?w=800&q=80` }}
          style={styles.coverImage}
        />

        <View style={styles.content}>
          <Text style={styles.title}>{ad.title}</Text>
          <Text style={styles.description}>{ad.fullDescription}</Text>

          <View style={styles.infoContainer}>
            <View style={styles.infoItem}>
              <DollarSign size={20} color="#6B6B6B" />
              <Text style={styles.infoText}>{ad.price}</Text>
            </View>
            
            {ad.validity && (
              <View style={styles.infoItem}>
                <Clock size={20} color="#6B6B6B" />
                <Text style={styles.infoText}>{ad.validity}</Text>
              </View>
            )}

            {ad.locations && (
              <View style={styles.infoItem}>
                <MapPin size={20} color="#6B6B6B" />
                <Text style={styles.infoText}>{ad.locations.join(', ')}</Text>
              </View>
            )}
          </View>

          {ad.includes && (
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>What's Included</Text>
              {ad.includes.map((item, index) => (
                <Text key={index} style={styles.listItem}>• {item}</Text>
              ))}
            </View>
          )}

          {ad.terms && (
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Terms & Conditions</Text>
              {ad.terms.map((term, index) => (
                <Text key={index} style={styles.listItem}>• {term}</Text>
              ))}
            </View>
          )}

          {ad.venues && (
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Available Venues</Text>
              {ad.venues.map((venue, index) => (
                <Text key={index} style={styles.listItem}>• {venue}</Text>
              ))}
            </View>
          )}

          <TouchableOpacity style={styles.claimButton}>
            <Text style={styles.claimButtonText}>Claim Offer</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  header: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: Platform.OS === 'web' ? 16 : 0,
    paddingTop: Platform.OS === 'web' ? 16 : 48,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 16,
  },
  shareButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  coverImage: {
    width: '100%',
    height: 300,
  },
  content: {
    padding: 16,
  },
  title: {
    fontSize: 28,
    fontWeight: '700',
    color: '#2D2D2D',
    marginBottom: 8,
  },
  description: {
    fontSize: 16,
    color: '#2D2D2D',
    lineHeight: 24,
    marginBottom: 24,
  },
  infoContainer: {
    marginBottom: 24,
  },
  infoItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  infoText: {
    fontSize: 14,
    color: '#6B6B6B',
    marginLeft: 8,
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: '600',
    color: '#2D2D2D',
    marginBottom: 12,
  },
  listItem: {
    fontSize: 16,
    color: '#2D2D2D',
    paddingVertical: 8,
  },
  claimButton: {
    backgroundColor: '#DA3743',
    padding: 16,
    borderRadius: 8,
    alignItems: 'center',
  },
  claimButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
  },
});