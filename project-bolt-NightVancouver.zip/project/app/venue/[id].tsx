import { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Image, TouchableOpacity, Platform } from 'react-native';
import { useLocalSearchParams, router } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { ChevronLeft, Star, MapPin, Clock, DollarSign, Share2, Heart, Calendar } from 'lucide-react-native';

const VENUE_DATA = {
  '1': {
    id: '1',
    name: 'Le Bernardin',
    image: 'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4',
    cuisine: 'French',
    price: '$$$$',
    rating: 4.8,
    location: 'Midtown Manhattan',
    address: '155 W 51st St, New York, NY 10019',
    description: "Le Bernardin, New York's internationally acclaimed four-star seafood restaurant, features Chef Eric Ripert's creative French cuisine.",
    hours: '5:30 PM - 10:30 PM',
    photos: [
      'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4',
      'https://images.unsplash.com/photo-1414235077428-338989a2e8c0',
      'https://images.unsplash.com/photo-1559339352-11d035aa65de',
    ],
  },
  '2': {
    id: '2',
    name: 'Nobu Downtown',
    image: 'https://images.unsplash.com/photo-1555396273-367ea4eb4db5',
    cuisine: 'Japanese',
    price: '$$$$',
    rating: 4.7,
    location: 'Financial District',
    address: '195 Broadway, New York, NY 10007',
    description: 'World-renowned Japanese restaurant offering innovative new-style cuisine with an extensive menu of creative dishes and spectacular cocktails.',
    hours: '11:30 AM - 11:00 PM',
    photos: [
      'https://images.unsplash.com/photo-1555396273-367ea4eb4db5',
      'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4',
      'https://images.unsplash.com/photo-1414235077428-338989a2e8c0',
    ],
  },
  '3': {
    id: '3',
    name: 'Gramercy Tavern',
    image: 'https://images.unsplash.com/photo-1550966871-3ed3cdb5ed0c',
    cuisine: 'American',
    price: '$$$',
    rating: 4.6,
    location: 'Gramercy',
    address: '42 E 20th St, New York, NY 10003',
    description: "One of America's most beloved restaurants, Gramercy Tavern serves innovative American cuisine in a rustic yet elegant setting.",
    hours: '12:00 PM - 11:00 PM',
    photos: [
      'https://images.unsplash.com/photo-1550966871-3ed3cdb5ed0c',
      'https://images.unsplash.com/photo-1517248135467-4c7edcad34c4',
      'https://images.unsplash.com/photo-1414235077428-338989a2e8c0',
    ],
  },
  '4': {
    id: '4',
    name: 'Library Café',
    image: 'https://images.unsplash.com/photo-1559925393-8be0ec4767c8',
    cuisine: 'Study Café',
    price: '$',
    rating: 4.9,
    location: 'UBC Area',
    address: '123 University Blvd, Vancouver, BC',
    description: 'A quiet and cozy café perfect for studying, with unlimited coffee and comfortable seating.',
    hours: '7:00 AM - 11:00 PM',
    photos: [
      'https://images.unsplash.com/photo-1559925393-8be0ec4767c8',
      'https://images.unsplash.com/photo-1497633762265-9d179a990aa6',
      'https://images.unsplash.com/photo-1497032628192-86f99bcd76bc',
    ],
  },
  '5': {
    id: '5',
    name: 'The Pitch & Pint',
    image: 'https://images.unsplash.com/photo-1574096079513-d8259312b785',
    cuisine: 'Sports Bar',
    price: '$$',
    rating: 4.5,
    location: 'Gastown',
    address: '456 Water St, Vancouver, BC',
    description: 'Your premier destination for sports viewing, featuring multiple screens and a great selection of craft beers.',
    hours: '11:00 AM - 2:00 AM',
    photos: [
      'https://images.unsplash.com/photo-1574096079513-d8259312b785',
      'https://images.unsplash.com/photo-1567337710282-00832b415979',
      'https://images.unsplash.com/photo-1566633806327-68e152aaf26d',
    ],
  },
};

export default function VenueDetails() {
  const { id } = useLocalSearchParams();
  const [isFavorite, setIsFavorite] = useState(false);
  const venue = VENUE_DATA[id as keyof typeof VENUE_DATA];

  if (!venue) {
    return (
      <View style={styles.container}>
        <Text>Venue not found</Text>
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView>
        <View style={styles.header}>
          <TouchableOpacity
            style={styles.backButton}
            onPress={() => router.back()}>
            <ChevronLeft size={24} color="#fff" />
          </TouchableOpacity>
          <View style={styles.headerActions}>
            <TouchableOpacity style={styles.headerButton}>
              <Share2 size={24} color="#fff" />
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.headerButton}
              onPress={() => setIsFavorite(!isFavorite)}>
              <Heart
                size={24}
                color="#fff"
                fill={isFavorite ? '#fff' : 'none'}
              />
            </TouchableOpacity>
          </View>
        </View>

        <ScrollView
          horizontal
          pagingEnabled
          style={styles.photoGallery}
          showsHorizontalScrollIndicator={false}>
          {venue.photos.map((photo, index) => (
            <Image
              key={index}
              source={{ uri: `${photo}?w=800&q=80` }}
              style={styles.galleryImage}
            />
          ))}
        </ScrollView>

        <View style={styles.content}>
          <Text style={styles.name}>{venue.name}</Text>
          
          <View style={styles.ratingContainer}>
            <Star size={20} color="#DA3743" fill="#DA3743" />
            <Text style={styles.rating}>{venue.rating}</Text>
            <Text style={styles.cuisine}>• {venue.cuisine}</Text>
            <Text style={styles.price}>• {venue.price}</Text>
          </View>

          <View style={styles.infoContainer}>
            <View style={styles.infoItem}>
              <MapPin size={20} color="#6B6B6B" />
              <Text style={styles.infoText}>{venue.address}</Text>
            </View>
            <View style={styles.infoItem}>
              <Clock size={20} color="#6B6B6B" />
              <Text style={styles.infoText}>{venue.hours}</Text>
            </View>
            <View style={styles.infoItem}>
              <DollarSign size={20} color="#6B6B6B" />
              <Text style={styles.infoText}>Average $150 per person</Text>
            </View>
          </View>

          <Text style={styles.description}>{venue.description}</Text>

          <TouchableOpacity style={styles.reserveButton}>
            <Calendar size={20} color="#fff" />
            <Text style={styles.reserveButtonText}>Make a Reservation</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
  header: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 1,
    flexDirection: 'row',
    justifyContent: 'space-between',
    padding: Platform.OS === 'web' ? 16 : 0,
    paddingTop: Platform.OS === 'web' ? 16 : 48,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 16,
  },
  headerActions: {
    flexDirection: 'row',
    marginRight: 16,
  },
  headerButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 8,
  },
  photoGallery: {
    height: 300,
  },
  galleryImage: {
    width: Platform.OS === 'web' ? 800 : 400,
    height: 300,
  },
  content: {
    padding: 16,
  },
  name: {
    fontSize: 28,
    fontWeight: '700',
    color: '#2D2D2D',
    marginBottom: 8,
  },
  ratingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  rating: {
    fontSize: 16,
    fontWeight: '600',
    color: '#DA3743',
    marginLeft: 4,
    marginRight: 8,
  },
  cuisine: {
    fontSize: 16,
    color: '#6B6B6B',
    marginRight: 8,
  },
  price: {
    fontSize: 16,
    color: '#6B6B6B',
  },
  infoContainer: {
    marginBottom: 16,
  },
  infoItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  infoText: {
    fontSize: 14,
    color: '#6B6B6B',
    marginLeft: 8,
  },
  description: {
    fontSize: 16,
    color: '#2D2D2D',
    lineHeight: 24,
    marginBottom: 24,
  },
  reserveButton: {
    backgroundColor: '#DA3743',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 16,
    borderRadius: 8,
  },
  reserveButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '600',
    marginLeft: 8,
  },
});